package com.example.my_first_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
