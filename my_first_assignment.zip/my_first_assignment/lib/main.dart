import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        body: Center(
          child: Text(
            'Name: Danial Ahmed\n'
            'Skills: Web Developer\n'
            'Hobbies: Playing Cricket, Read Books\n'
            'Profession: Student',
            style: TextStyle(fontSize: 20),
            textAlign: TextAlign.left,
          ),
        ),
      ),
    );
  }
}
